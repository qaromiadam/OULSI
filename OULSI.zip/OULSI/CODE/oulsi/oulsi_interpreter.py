import operator

from oulsi_errors import OulsiError
from oulsi_parser import parse
from oulsi_engine import Screen

COMPARISONS = {
    ">": operator.gt,
    "<": operator.lt,
    "==": operator.eq,
    "!=": operator.ne,
}

# Not a valid variable name, so user programs can never clash with it
SCREEN = "#screen"


def run(source):
    env = {}
    try:
        execute(parse(source), env)
    finally:
        screen = env.pop(SCREEN, None)
        if screen is not None:
            screen.close()


def execute(statements, env):
    for stmt in statements:
        kind = stmt[0]

        if kind == "at":
            _, line, inner = stmt
            try:
                execute([inner], env)
            except OulsiError as err:
                if err.line is None:
                    err.line = line
                raise
            continue

        if kind == "set":
            _, name, expr = stmt
            env[name] = evaluate(expr, env)

        elif kind == "print":
            print(" ".join(str(evaluate(item, env)) for item in stmt[1]))

        elif kind == "add":
            _, amount_expr, name = stmt
            if name not in env:
                raise OulsiError(f"'{name}' has not been set yet")
            current = env[name]
            amount = evaluate(amount_expr, env)
            if not (is_number(current) and is_number(amount)):
                raise OulsiError("'add' and 'subtract' only work with numbers")
            env[name] = current + amount

        elif kind == "if":
            _, condition, body = stmt
            if evaluate_condition(condition, env):
                execute(body, env)

        elif kind == "repeat":
            _, count_expr, body = stmt
            count = evaluate(count_expr, env)
            if not isinstance(count, int) or count < 0:
                raise OulsiError("'repeat' needs a whole number, such as 3")
            for _ in range(count):
                execute(body, env)

        elif kind == "engine":
            execute(stmt[1], env)

        elif kind == "window":
            _, title_expr, width_expr, height_expr = stmt
            if SCREEN in env:
                raise OulsiError("a window is already open")
            env[SCREEN] = Screen(
                str(evaluate(title_expr, env)),
                whole(evaluate(width_expr, env), "window width"),
                whole(evaluate(height_expr, env), "window height"),
                lambda body: execute(body, env),
            )

        elif kind == "make":
            _, shape, name, label_expr, opts = stmt
            screen = get_screen(env)
            label = str(evaluate(label_expr, env)) if label_expr is not None else None
            x, y = pair(opts, "at", env, "position")
            w, h = pair(opts, "size", env, "size")
            color = str(evaluate(opts["color"], env)) if "color" in opts else None
            screen.add(shape, name, x, y, w, h, color, label)

        elif kind == "change":
            _, name, expr = stmt
            get_screen(env).set_text(name, str(evaluate(expr, env)))

        elif kind == "move":
            _, name, mode, x_expr, y_expr = stmt
            x = number(evaluate(x_expr, env), "move amount")
            y = number(evaluate(y_expr, env), "move amount")
            get_screen(env).move(name, mode, x, y)

        elif kind == "rotate":
            _, name, mode, angle_expr = stmt
            angle = number(evaluate(angle_expr, env), "angle")
            get_screen(env).rotate(name, mode, angle)

        elif kind == "color":
            _, name, expr = stmt
            get_screen(env).set_color(name, str(evaluate(expr, env)))

        elif kind == "remove":
            get_screen(env).remove(stmt[1])

        elif kind == "every":
            get_screen(env).on_frame(stmt[1])

        elif kind == "onclick":
            _, name, body = stmt
            get_screen(env).on_click(name, body)

        elif kind == "onkey":
            _, mode, key, body = stmt
            get_screen(env).on_key(mode, key, body)

        elif kind == "start":
            screen = get_screen(env)
            try:
                screen.start()
            finally:
                env.pop(SCREEN, None)


def evaluate_condition(condition, env):
    if condition[0] == "and":
        return evaluate_condition(condition[1], env) and evaluate_condition(condition[2], env)
    if condition[0] == "or":
        return evaluate_condition(condition[1], env) or evaluate_condition(condition[2], env)
    if condition[0] == "touches":
        return get_screen(env).touching(condition[1], condition[2])
    op, left, right = condition
    return COMPARISONS[op](evaluate(left, env), evaluate(right, env))


def evaluate(node, env):
    kind = node[0]

    if kind in ("num", "str"):
        return node[1]

    if kind == "var":
        name = node[1]
        if name not in env:
            raise OulsiError(f"'{name}' has not been set yet")
        return env[name]

    if kind == "word":
        # A bare word is a variable if one exists, otherwise it is just text (a color name)
        name = node[1]
        return env[name] if name in env else name

    if kind == "neg":
        value = evaluate(node[1], env)
        return -number(value, "only numbers can be made negative")

    if kind == "binop":
        _, op, left_node, right_node = node
        left = evaluate(left_node, env)
        right = evaluate(right_node, env)

        # Joining text and values: "Score: " + score
        if op == "+" and (isinstance(left, str) or isinstance(right, str)):
            return str(left) + str(right)

        try:
            if op == "+":
                return left + right
            if op == "-":
                return left - right
            if op == "*":
                return left * right
            if op == "/":
                if right == 0:
                    raise OulsiError("cannot divide by zero")
                result = left / right
                return int(result) if result.is_integer() else result
        except TypeError:
            raise OulsiError(f"cannot use {op} with these values")

    raise OulsiError(f"unknown expression: {kind}")


# ---- helpers ---------------------------------------------------------

def get_screen(env):
    if SCREEN not in env:
        raise OulsiError('no window is open, start with: window "My Game" 400 300')
    return env[SCREEN]


def is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def number(value, what):
    if not is_number(value):
        raise OulsiError(f"{what} must be a number")
    return value


def whole(value, what):
    return int(number(value, what))


def pair(opts, key, env, what):
    if key not in opts:
        return None, None
    first, second = opts[key]
    return number(evaluate(first, env), what), number(evaluate(second, env), what)
