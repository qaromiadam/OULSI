import math

from oulsi_errors import OulsiError

# tkinter is imported only when a window is opened, so text-only
# programs still run on Python builds that do not include it.
tk = None

FRAME_MS = 16  # about 60 frames per second
TEXT_CHAR_W = 8
TEXT_H = 20
DEFAULT_COLORS = {"box": "black", "circle": "black", "text": "black", "button": "lightgray"}
DEFAULT_SIZES = {"box": (50, 50), "circle": (50, 50), "button": (120, 40)}


class Shape:
    """A box, circle, text label, or button. Position (x, y) is the center."""

    def __init__(self, kind, x, y, w, h, color, text=None):
        self.kind = kind
        self.x, self.y = x, y
        self.w, self.h = w, h
        self.color = color
        self.text = text
        self.angle = 0.0
        self.on_click = None

    def corners(self):
        hw, hh = self.w / 2, self.h / 2
        a = math.radians(self.angle)
        c, s = math.cos(a), math.sin(a)
        points = []
        for dx, dy in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)):
            points.append((self.x + dx * c - dy * s, self.y + dx * s + dy * c))
        return points

    def bounds(self):
        if self.kind == "circle":
            r = self.w / 2
            return self.x - r, self.y - r, self.x + r, self.y + r
        xs, ys = zip(*self.corners())
        return min(xs), min(ys), max(xs), max(ys)

    def hit(self, px, py):
        if self.kind == "circle":
            return math.hypot(px - self.x, py - self.y) <= self.w / 2
        x1, y1, x2, y2 = self.bounds()
        return x1 <= px <= x2 and y1 <= py <= y2


class Screen:
    def __init__(self, title, width, height, run_body):
        global tk
        if tk is None:
            try:
                import tkinter as tk_module
            except ImportError:
                raise OulsiError("graphics need tkinter, install it with: sudo apt install python3-tk")
            tk = tk_module
        try:
            self.root = tk.Tk()
        except tk.TclError:
            raise OulsiError("could not open a window, is a display available?")
        self.root.title(title)
        self.root.resizable(False, False)
        self.width = width
        self.height = height
        self.canvas = tk.Canvas(self.root, width=width, height=height,
                                bg="white", highlightthickness=0)
        self.canvas.pack()

        self.shapes = {}
        self.frame_bodies = []
        self.key_bodies = []  # (mode, key, body)
        self.pressed = set()
        self.run_body = run_body
        self.error = None
        self.running = False

        self.root.bind("<KeyPress>", self._key_down)
        self.root.bind("<KeyRelease>", self._key_up)
        self.canvas.bind("<Button-1>", self._click)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    # ---- shapes --------------------------------------------------------

    def _check_color(self, color):
        try:
            self.canvas.winfo_rgb(color)
        except tk.TclError:
            raise OulsiError(
                f"unknown color '{color}', try names like \"red\", \"blue\" or \"#ff8800\""
            )
        return color

    def get(self, name):
        if name not in self.shapes:
            raise OulsiError(f"there is no shape named '{name}', create it with make first")
        return self.shapes[name]

    def add(self, kind, name, x, y, w, h, color, text):
        x = self.width / 2 if x is None else x
        y = self.height / 2 if y is None else y
        if kind == "text":
            w = len(text) * TEXT_CHAR_W if w is None else w
            h = TEXT_H if h is None else h
        else:
            default_w, default_h = DEFAULT_SIZES[kind]
            w = default_w if w is None else w
            h = default_h if h is None else h
        if kind == "circle":
            h = w
        if w <= 0 or h <= 0:
            raise OulsiError("sizes must be more than zero")
        color = self._check_color(color or DEFAULT_COLORS[kind])
        self.shapes[name] = Shape(kind, x, y, w, h, color, text)

    def remove(self, name):
        self.get(name)
        del self.shapes[name]

    def move(self, name, mode, x, y):
        shape = self.get(name)
        if mode == "by":
            shape.x += x
            shape.y += y
        else:
            shape.x, shape.y = x, y

    def rotate(self, name, mode, angle):
        shape = self.get(name)
        shape.angle = angle if mode == "to" else shape.angle + angle

    def set_color(self, name, color):
        self.get(name).color = self._check_color(color)

    def set_text(self, name, text):
        shape = self.get(name)
        if shape.kind not in ("text", "button"):
            raise OulsiError(f"'{name}' is not a text or button, so it cannot change its text")
        shape.text = text

    def touching(self, first, second):
        a = self.get(first).bounds()
        b = self.get(second).bounds()
        return a[0] <= b[2] and b[0] <= a[2] and a[1] <= b[3] and b[1] <= a[3]

    # ---- handlers ------------------------------------------------------

    def on_frame(self, body):
        self.frame_bodies.append(body)

    def on_click(self, name, body):
        self.get(name).on_click = body

    def on_key(self, mode, key, body):
        self.key_bodies.append((mode, key, body))

    # ---- events --------------------------------------------------------

    def _run(self, body):
        if not self.running:
            return
        try:
            self.run_body(body)
        except Exception as err:
            self._fail(err)

    def _key_down(self, event):
        key = event.keysym.lower()
        if key in self.pressed:
            return  # ignore key-repeat while held
        self.pressed.add(key)
        for mode, wanted, body in list(self.key_bodies):
            if mode == "pressed" and wanted == key:
                self._run(body)

    def _key_up(self, event):
        self.pressed.discard(event.keysym.lower())

    def _click(self, event):
        for shape in reversed(list(self.shapes.values())):
            if shape.on_click is not None and shape.hit(event.x, event.y):
                self._run(shape.on_click)
                return

    # ---- drawing and the game loop --------------------------------------

    def _draw(self):
        c = self.canvas
        c.delete("all")
        for shape in self.shapes.values():
            if shape.kind == "circle":
                x1, y1, x2, y2 = shape.bounds()
                c.create_oval(x1, y1, x2, y2, fill=shape.color, outline="")
            elif shape.kind == "text":
                c.create_text(shape.x, shape.y, text=shape.text,
                              fill=shape.color, font=("Arial", 14))
            else:
                flat = [v for point in shape.corners() for v in point]
                outline = "black" if shape.kind == "button" else ""
                c.create_polygon(*flat, fill=shape.color, outline=outline)
                if shape.kind == "button":
                    c.create_text(shape.x, shape.y, text=shape.text, font=("Arial", 12))

    def _tick(self):
        if not self.running:
            return
        for body in list(self.frame_bodies):
            self._run(body)
        for mode, key, body in list(self.key_bodies):
            if mode == "held" and key in self.pressed:
                self._run(body)
        if self.running:
            try:
                self._draw()
            except tk.TclError as err:
                self._fail(err)
                return
            self.root.after(FRAME_MS, self._tick)

    def _fail(self, err):
        if self.error is None:
            self.error = err if isinstance(err, OulsiError) else OulsiError(f"graphics error: {err}")
        self.close()

    def close(self):
        self.running = False
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def start(self):
        self.running = True
        self.root.after(0, self._tick)
        self.root.focus_force()
        self.root.mainloop()
        if self.error is not None:
            raise self.error
