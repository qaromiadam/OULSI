import re

from oulsi_errors import OulsiError

TOKEN_SPEC = [
    ("ENGINE",   r"«[^»]*»"),
    ("NUMBER",   r"\d+(\.\d+)?"),
    ("STRING",   r'"[^"]*"'),
    ("NAME",     r"[A-Za-z_][A-Za-z_0-9]*"),
    ("OP",       r"[+\-*/=()]"),
    ("COLON",    r":"),
    ("NEWLINE",  r"\n"),
    ("SKIP",     r"[ \t\r,]+"),  # commas are ignored, so "print a, b" works
    ("COMMENT",  r"#[^\n]*"),
    ("MISMATCH", r"."),
]

TOKEN_RE = re.compile("|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPEC))

# Words that do nothing, so they are skipped: "move the ball" == "move ball"
FILLER = {"the"}


def tokenize(source):
    tokens = []
    line_no = 1
    for match in TOKEN_RE.finditer(source):
        kind = match.lastgroup
        value = match.group()
        if kind == "NEWLINE":
            tokens.append(("NEWLINE", value, line_no))
            line_no += 1
        elif kind in ("SKIP", "COMMENT"):
            continue
        elif kind == "MISMATCH":
            if value == "«":
                raise OulsiError("YOU FORGOT »", line=line_no)
            raise OulsiError(f"unexpected character {value!r}", line=line_no)
        elif kind == "ENGINE":
            text = " ".join(value[1:-1].lower().split())
            tokens.append(("ENGINE", text, line_no))
            line_no += value.count("\n")
        elif kind == "NAME":
            word = value.lower()
            if word not in FILLER:
                tokens.append(("NAME", word, line_no))
        else:
            tokens.append((kind, value, line_no))
    tokens.append(("EOF", None, line_no))
    return tokens
