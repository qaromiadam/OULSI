import re

PAIRS = {"{": "}", "<": ">", "(": ")", "[": "]"}
CLOSERS = set(PAIRS.values())


class OulsiError(Exception):
    """An error in an Oulsi program. `line` is filled in as the error travels up."""

    def __init__(self, message, line=None, bracket_fix=False):
        super().__init__(message)
        self.message = message
        self.line = line
        self.bracket_fix = bracket_fix


def check_brackets(text):
    """Return (problem, fixed_text). problem is None when the brackets are balanced.
    fixed_text is the text with the missing closing brackets added, or None."""
    stack = []
    for ch in text:
        if ch in PAIRS:
            stack.append(ch)
        elif ch in CLOSERS:
            if not stack:
                return f"UNEXPECTED {ch}", None
            opened = stack.pop()
            if PAIRS[opened] != ch:
                return f"YOU FORGOT {PAIRS[opened]}", None
    if stack:
        missing = "".join(PAIRS[c] for c in reversed(stack))
        return f"YOU FORGOT {missing}", text + missing
    return None, text


def _fix_engine_brackets(src):
    m = re.search(r"«([^»]*)»?", src)
    if not m:
        return None
    _, fixed_inner = check_brackets(m.group(1))
    if fixed_inner is None:
        return None
    return src[:m.start()] + "«" + fixed_inner + "»" + src[m.end():]


def format_error(err, source):
    """Build the FATAL message: line number, command word, the line, and a fix if known."""
    lines = source.splitlines()
    if err.line is None or not 1 <= err.line <= len(lines):
        return f"FATAL: {err.message}"

    src = lines[err.line - 1]
    shown = src.strip()
    word = re.match(r"[A-Za-z]+", shown)
    keyword = word.group().upper() if word else "CODE"

    out = [f"FATAL: LINE {err.line} IN {keyword}, {err.message}", "", f"    {shown}"]
    if err.bracket_fix:
        fixed = _fix_engine_brackets(src)
        if fixed:
            out += ["", "Should be:", "", f"    {fixed.strip()}"]
    return "\n".join(out)
