import sys

from oulsi_errors import OulsiError, format_error
from oulsi_interpreter import run


def main():
    if len(sys.argv) != 2:
        print("Usage: python oulsi.py yourfile.oul")
        sys.exit(1)

    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        print(f"Could not find file: {path}")
        sys.exit(1)

    try:
        run(source)
    except OulsiError as err:
        print(format_error(err, source))
        sys.exit(1)
    except Exception as err:
        print(f"FATAL: something went wrong inside Oulsi: {err}")
        sys.exit(1)


if __name__ == "__main__":
    main()
