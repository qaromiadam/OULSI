import re

from oulsi_lexer import tokenize
from oulsi_errors import OulsiError, check_brackets

KEYWORDS = {
    "set", "to", "calculate", "print", "say", "add", "subtract", "from",
    "if", "is", "not", "greater", "less", "equal", "equals", "than",
    "and", "or", "repeat", "times", "end", "use", "run", "finish",
    "when", "every", "touches", "window", "start", "make", "change",
    "move", "turn", "rotate", "color", "remove",
}
SHAPES = ("box", "circle", "text", "button")
OPTIONS = ("at", "size", "color")
ENGINE_NAME = re.compile(r"oulsi (game|graphics|interactiv\w*) engine")
ENGINE_LABEL = {
    "game": "game engine",
    "graphics": "graphics engine",
    "interactiveness": "interactiveness engine",
}


def engines_from(text):
    """Turn an engine name such as 'oulsi advanced' into a set of engine names."""
    if "oulsi advanced" in text:
        return {"game", "graphics", "interactiveness"}
    found = set()
    for match in ENGINE_NAME.findall(text):
        found.add("interactiveness" if match.startswith("interactiv") else match)
    return found


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.engines = None  # set while inside a use/finish block

    # ---- helpers -------------------------------------------------------

    def peek(self, offset=0):
        return self.tokens[min(self.pos + offset, len(self.tokens) - 1)]

    def advance(self):
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def error(self, msg):
        kind, value, line = self.peek()
        if kind == "EOF":
            shown = "end of file"
        elif kind == "NEWLINE":
            shown = "end of line"
        else:
            shown = repr(value)
        raise OulsiError(f"{msg}, found {shown}")

    def is_word(self, word):
        kind, value, _ = self.peek()
        return kind == "NAME" and value == word

    def expect_word(self, word):
        if self.is_word(word):
            self.advance()
        else:
            self.error(f"expected '{word}'")

    def expect_op(self, op):
        kind, value, _ = self.peek()
        if kind == "OP" and value == op:
            self.advance()
        else:
            self.error(f"expected '{op}'")

    def expect_name(self):
        kind, value, _ = self.peek()
        if kind == "NAME" and value not in KEYWORDS:
            self.advance()
            return value
        self.error("expected a name")

    def skip_newlines(self):
        while self.peek()[0] == "NEWLINE":
            self.advance()

    def end_of_line(self):
        if self.peek()[0] == "EOF":
            return
        if self.peek()[0] != "NEWLINE":
            self.error("expected end of line")
        self.advance()

    def finish_line(self, node):
        self.end_of_line()
        return node

    def optional_colon(self):
        if self.peek()[0] == "COLON":
            self.advance()

    def is_shape(self):
        return self.peek()[0] == "NAME" and self.peek()[1] in SHAPES

    def at_option(self):
        return self.peek()[0] == "NAME" and self.peek()[1] in OPTIONS

    def skip_article(self):
        if self.is_word("a") or self.is_word("an"):
            self.advance()

    def starts_value(self):
        kind, value, _ = self.peek()
        return kind == "NUMBER" or (kind == "OP" and value in ("(", "-"))

    def need(self, engine, command, line):
        """Stop with a clear message if a command is used without its engine running."""
        if self.engines is None or engine not in self.engines:
            raise OulsiError(
                f"invalid command '{command}', you must run the engine first. "
                f"It needs the oulsi {ENGINE_LABEL[engine]}. "
                f"Wrap your code in use «oulsi advanced» ... finish «oulsi advanced»"
            )

    # ---- blocks --------------------------------------------------------

    def parse_program(self):
        statements = []
        self.skip_newlines()
        while self.peek()[0] != "EOF":
            statements.append(self.parse_statement())
            self.skip_newlines()
        return statements

    def parse_body(self, stops):
        statements = []
        self.skip_newlines()
        while not (self.peek()[0] == "NAME" and self.peek()[1] in stops):
            if self.peek()[0] == "EOF":
                self.error(f"missing '{stops[0]}' to close this block")
            statements.append(self.parse_statement())
            self.skip_newlines()
        return statements

    def parse_block(self):
        body = self.parse_body(("end",))
        self.advance()  # consume 'end'
        self.end_of_line()
        return body

    def parse_engine_block(self):
        line = self.advance()[2]  # 'use' or 'run'
        kind, text, _ = self.peek()
        if kind != "ENGINE":
            self.error("expected an engine name in «...», such as «oulsi graphics engine»")
        self.advance()

        problem, _ = check_brackets(text)
        if problem:
            raise OulsiError(problem, bracket_fix=True)
        engines = engines_from(text)
        if not engines:
            raise OulsiError(f"unknown engine «{text}»")
        if self.engines is not None:
            raise OulsiError(f"engine blocks cannot be nested")
        if ("game" in engines or "interactiveness" in engines) and "graphics" not in engines:
            raise OulsiError(
                f"the game and interactiveness engines must be paired "
                f"with the graphics engine"
            )
        self.end_of_line()

        self.engines = engines
        body = self.parse_body(("finish",))
        self.advance()  # consume 'finish'

        kind, text, finish_line = self.peek()
        if kind != "ENGINE":
            self.error("expected the engine name in «...» after 'finish'")
        problem, _ = check_brackets(text)
        if problem:
            raise OulsiError(problem, line=finish_line, bracket_fix=True)
        if engines_from(text) != engines:
            raise OulsiError(
                f"'finish' does not match the engine block "
                f"that started on line {line}",
                line=finish_line,
            )
        self.advance()
        self.end_of_line()
        self.engines = None
        return ("engine", body)

    # ---- statements ----------------------------------------------------

    def parse_statement(self):
        # Remember the line of every statement so runtime errors can report it
        line = self.peek()[2]
        try:
            return ("at", line, self._parse_statement())
        except OulsiError as err:
            if err.line is None:
                err.line = line
            raise

    def _parse_statement(self):
        kind, word, line = self.peek()
        if kind != "NAME":
            self.error("expected a command")

        if word == "end":
            self.error("'end' without a block to close")

        if word in ("set", "calculate"):
            self.advance()
            name = self.expect_name()
            if self.peek()[0] == "OP" and self.peek()[1] == "=":
                self.advance()
            else:
                self.expect_word("to")
            return self.finish_line(("set", name, self.parse_expr()))

        if word in ("print", "say"):
            self.advance()
            items = []
            while self.peek()[0] not in ("NEWLINE", "EOF"):
                items.append(self.parse_expr())
            if not items:
                self.error("expected something to print")
            return self.finish_line(("print", items))

        if word == "add":
            self.advance()
            amount = self.parse_expr()
            self.expect_word("to")
            name = self.expect_name()
            return self.finish_line(("add", amount, name))

        if word == "subtract":
            self.advance()
            amount = self.parse_expr()
            self.expect_word("from")
            name = self.expect_name()
            return self.finish_line(("add", ("neg", amount), name))

        if word == "if":
            self.advance()
            condition = self.parse_condition()
            self.optional_colon()
            return ("if", condition, self.parse_block())

        if word == "repeat":
            self.advance()
            count = self.parse_expr()
            self.expect_word("times")
            self.optional_colon()
            return ("repeat", count, self.parse_block())

        if word == "every":
            self.advance()
            self.expect_word("frame")
            self.need("graphics", "every frame", line)
            self.optional_colon()
            return ("every", self.parse_block())

        if word == "when":
            return self.parse_when()

        if word in ("use", "run"):
            return self.parse_engine_block()

        if word == "window":
            self.need("graphics", "window", line)
            self.advance()
            title = self.parse_expr()
            width = self.parse_value()
            height = self.parse_value()
            return self.finish_line(("window", title, width, height))

        if word == "start":
            self.need("graphics", "start", line)
            self.advance()
            return self.finish_line(("start",))

        if word == "make":
            return self.parse_make()

        if word == "change":
            self.need("graphics", "change", line)
            self.advance()
            name = self.expect_name()
            if self.is_word("to"):
                self.advance()
            return self.finish_line(("change", name, self.parse_expr()))

        if word == "move":
            return self.parse_move()

        if word in ("turn", "rotate"):
            self.need("graphics", word, line)
            self.advance()
            name = self.expect_name()
            mode = "by"
            if self.is_word("by") or self.is_word("to"):
                mode = self.advance()[1]
            angle = self.parse_value()
            return self.finish_line(("rotate", name, mode, angle))

        if word == "color":
            self.need("graphics", "color", line)
            self.advance()
            name = self.expect_name()
            return self.finish_line(("color", name, self.parse_color()))

        if word == "remove":
            self.need("graphics", "remove", line)
            self.advance()
            name = self.expect_name()
            return self.finish_line(("remove", name))

        self.error("unknown command")

    def parse_move(self):
        line = self.advance()[2]
        self.need("graphics", "move", line)
        name = self.expect_name()

        # Easy directions: move ball right 5, move ball up 3
        if self.is_word("right"):
            self.advance()
            return self.finish_line(("move", name, "by", self.parse_value(), ("num", 0)))
        if self.is_word("left"):
            self.advance()
            return self.finish_line(("move", name, "by", ("neg", self.parse_value()), ("num", 0)))
        if self.is_word("up"):
            self.advance()
            return self.finish_line(("move", name, "by", ("num", 0), ("neg", self.parse_value())))
        if self.is_word("down"):
            self.advance()
            return self.finish_line(("move", name, "by", ("num", 0), self.parse_value()))

        # move ball by 3 4 (relative) or move ball to 200 50 (absolute)
        mode = "to"
        if self.is_word("by") or self.is_word("to"):
            mode = self.advance()[1]
        x = self.parse_value()
        y = self.parse_value()
        return self.finish_line(("move", name, mode, x, y))

    def parse_make(self):
        line = self.advance()[2]
        if self.is_shape():
            shape = self.advance()[1]
            name = self.expect_name()
        else:
            # Also accepts: make ball a circle
            name = self.expect_name()
            self.skip_article()
            if not self.is_shape():
                self.error("expected box, circle, text or button")
            shape = self.advance()[1]

        if shape == "button":
            self.need("interactiveness", "make button", line)
        else:
            self.need("graphics", f"make {shape}", line)

        label = None
        if shape in ("text", "button") and self.peek()[0] != "NEWLINE" and not self.at_option():
            label = self.parse_expr()

        opts = {}
        while self.at_option():
            opt = self.advance()[1]
            if opt == "color":
                opts["color"] = self.parse_color()
            else:
                first = self.parse_value()
                # 'size 20' gives a square or circle; 'size 80 15' gives width and height
                if opt == "at" or self.starts_value():
                    second = self.parse_value()
                else:
                    second = first
                opts[opt] = (first, second)
        return self.finish_line(("make", shape, name, label, opts))

    def parse_when(self):
        line = self.advance()[2]  # 'when'

        # Collect the words before 'is', e.g. "left arrow", "space", "reset"
        words = []
        while not self.is_word("is"):
            kind, value, _ = self.peek()
            if kind == "STRING":
                words.append(value[1:-1].lower())
            elif kind == "NAME":
                words.append(value)
            else:
                self.error("expected a key or button name before 'is'")
            self.advance()
        self.advance()  # 'is'

        # Drop the filler words so "left arrow" becomes "left"
        names = [w for w in words if w not in ("key", "arrow")]
        if not names:
            self.error("expected a key or button name before 'is'")

        if self.is_word("clicked"):
            if len(words) != 1:
                self.error("expected one button name before 'is clicked'")
            self.need("interactiveness", "when ... is clicked", line)
            self.advance()
            self.optional_colon()
            return ("onclick", words[0], self.parse_block())

        if self.is_word("held") or self.is_word("pressed"):
            self.need("interactiveness", "when key ... is held", line)
            mode = self.advance()[1]
            self.optional_colon()
            return ("onkey", mode, " ".join(names), self.parse_block())

        self.error("expected 'held', 'pressed' or 'clicked' after 'is'")

    # ---- conditions ----------------------------------------------------

    def parse_condition(self):
        node = self.parse_single_condition()
        while self.is_word("and") or self.is_word("or"):
            op = self.advance()[1]
            node = (op, node, self.parse_single_condition())
        return node

    def parse_single_condition(self):
        # if ball touches paddle
        if self.peek()[0] == "NAME" and self.peek(1)[0] == "NAME" and self.peek(1)[1] == "touches":
            line = self.peek()[2]
            first = self.expect_name()
            self.advance()  # 'touches'
            second = self.expect_name()
            self.need("game", "touches", line)
            return ("touches", first, second)

        left = self.parse_expr()
        self.expect_word("is")

        negate = False
        if self.is_word("not"):
            self.advance()
            negate = True

        if self.is_word("greater"):
            self.advance()
            self.expect_word("than")
            op = ">"
        elif self.is_word("less"):
            self.advance()
            self.expect_word("than")
            op = "<"
        elif self.is_word("equal") or self.is_word("equals"):
            self.advance()
            if self.is_word("to"):
                self.advance()
            op = "=="
        else:
            op = "=="  # plain 'if score is 5'

        right = self.parse_expr()
        if negate:
            if op != "==":
                self.error("'is not' can only be used with a value, such as 'is not 5'")
            op = "!="
        return (op, left, right)

    # ---- values and expressions ----------------------------------------

    def parse_color(self):
        """Colors can be bare words (red) or quoted ("red")."""
        kind, value, _ = self.peek()
        if kind == "NAME" and value not in KEYWORDS and value not in OPTIONS:
            self.advance()
            return ("word", value)
        return self.parse_factor()

    def parse_value(self):
        """A single value with no math, so 'move ball by 0 -3' reads as two numbers.
        Use brackets for math: move ball by (speed * 2) 0"""
        return self.parse_factor()

    def parse_expr(self):
        node = self.parse_term()
        while self.peek()[0] == "OP" and self.peek()[1] in ("+", "-"):
            op = self.advance()[1]
            node = ("binop", op, node, self.parse_term())
        return node

    def parse_term(self):
        node = self.parse_factor()
        while self.peek()[0] == "OP" and self.peek()[1] in ("*", "/"):
            op = self.advance()[1]
            node = ("binop", op, node, self.parse_factor())
        return node

    def parse_factor(self):
        kind, value, _ = self.peek()

        if kind == "NUMBER":
            self.advance()
            number = float(value) if "." in value else int(value)
            return ("num", number)

        if kind == "STRING":
            self.advance()
            return ("str", value[1:-1])

        if kind == "NAME":
            if value in KEYWORDS:
                self.error("expected a value, not a command word")
            self.advance()
            return ("var", value)

        if kind == "OP" and value == "(":
            self.advance()
            node = self.parse_expr()
            self.expect_op(")")
            return node

        if kind == "OP" and value == "-":
            self.advance()
            return ("neg", self.parse_factor())

        self.error("expected a value")


def parse(source):
    return Parser(tokenize(source)).parse_program()
