OULSI - a Python-based language with plain English commands

Run a program:     python oulsi.py examples/hello.oul
Play the game:     python oulsi.py examples/game.oul

Requirements: Python 3.8+. Graphics and games use tkinter, which comes
with Python on Windows and macOS. On Linux: sudo apt install python3-tk

Files:
  oulsi.py              the runner you execute
  oulsi_lexer.py        splits code into tokens
  oulsi_parser.py       turns tokens into a program tree
  oulsi_interpreter.py  runs the program tree
  oulsi_engine.py       window, shapes, keys, game loop (tkinter)
  oulsi_errors.py       shared error type
